/**
 * ====================================
 * GENERADOR DE PDF - CONAGUA
 * Aplicación principal
 * ====================================
 */

// Variables globales
let currentTemplateConfig = null;

/**
 * ====================================
 * INICIALIZACIÓN
 * ====================================
 */
document.addEventListener('DOMContentLoaded', function() {
  console.log('🚀 Inicializando aplicación...');
  loadTemplates();
  attachEventListeners();
  showNoTemplateMessage(); // Mostrar mensaje inicial
});

/**
 * Adjuntar event listeners
 */
function attachEventListeners() {
  // Cambio de plantilla
  const templateSelect = document.getElementById('templateSelect');
  if (templateSelect) {
    templateSelect.addEventListener('change', onTemplateChange);
  }
}

/**
 * ====================================
 * GESTIÓN DE PLANTILLAS
 * ====================================
 */

/**
 * Cargar plantillas disponibles desde el servidor
 */
async function loadTemplates() {
  try {
    const response = await fetch('/api/templates');
    const data = await response.json();

    if (data.success && data.templates.length > 0) {
      const select = document.getElementById('templateSelect');
      data.templates.forEach(template => {
        const option = document.createElement('option');
        option.value = template;
        option.textContent = formatTemplateName(template);
        select.appendChild(option);
      });
      console.log(`✅ ${data.count} plantillas cargadas`);
    } else {
      showMessage('⚠️ No se encontraron plantillas disponibles', 'error');
    }
  } catch (error) {
    console.error('❌ Error cargando plantillas:', error);
    showMessage('❌ Error al cargar las plantillas. Por favor, recarga la página.', 'error');
  }
}

/**
 * Formatear nombre de plantilla para mostrar
 */
function formatTemplateName(fileName) {
  return fileName
    .replace('.html', '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, l => l.toUpperCase());
}

/**
 * Mapeo de nombres de archivo a IDs de configuración
 */
function getTemplateIdFromFileName(fileName) {
  const mapping = {
    'Alta_de_cuenta_de_usuario_interno.html': 'alta_usuario_interno',
    'Alta_de_cuenta_de_servicio.html': 'alta_cuenta_servicio',
    'Baja_de_cuenta_de_usuario_interno.html': 'baja_usuario_interno',
    'Baja_de_cuenta_de_usuario_externo.html': 'baja_usuario_externo',
    'Baja_de_cuenta_de_servicio.html': 'baja_cuenta_servicio',
    'Cambio_en_cuenta_de_usuario_interno.html': 'cambio_usuario_interno',
    'Cambio_en_cuenta_de_usuario_externo.html': 'cambio_usuario_externo',
    'Cambio_en_cuenta_de_servicio.html': 'cambio_cuenta_servicio'
  };
  return mapping[fileName] || '';
}

/**
 * Evento cuando se selecciona una plantilla
 */
async function onTemplateChange(event) {
  const selectedTemplate = event.target.value;
  const templateInfo = document.getElementById('templateInfo');
  
  if (!selectedTemplate) {
    // Mostrar mensaje de "sin plantilla"
    showNoTemplateMessage();
    templateInfo.classList.remove('active');
    templateInfo.textContent = '';
    return;
  }

  // Ocultar mensaje y mostrar formulario dinámico
  hideNoTemplateMessage();
  showDynamicForm();

  // Obtener configuración de la plantilla
  try {
    const templateId = getTemplateIdFromFileName(selectedTemplate);
    const response = await fetch(`/api/template-config/${templateId}`);
    const data = await response.json();

    if (data.success) {
      currentTemplateConfig = data.config;
      
      // Mostrar información de la plantilla
      templateInfo.textContent = `📄 ${data.config.description}`;
      templateInfo.classList.add('active');
      
      // Renderizar formulario
      renderDynamicForm(data.config);
    } else {
      showMessage('❌ Error al cargar la configuración de la plantilla', 'error');
    }
  } catch (error) {
    console.error('❌ Error cargando configuración:', error);
    showMessage('❌ Error al cargar la configuración de la plantilla', 'error');
  }
}

/**
 * ====================================
 * RENDERIZADO DE FORMULARIOS
 * ====================================
 */

/**
 * Mostrar mensaje cuando no hay plantilla seleccionada
 */
function showNoTemplateMessage() {
  const noTemplateMsg = document.getElementById('noTemplateMessage');
  const dynamicForm = document.getElementById('dynamicFormContainer');
  
  if (noTemplateMsg) {
    noTemplateMsg.classList.remove('hidden');
  }
  if (dynamicForm) {
    dynamicForm.classList.add('hidden');
  }
  
  currentTemplateConfig = null;
}

/**
 * Ocultar mensaje de "sin plantilla"
 */
function hideNoTemplateMessage() {
  const noTemplateMsg = document.getElementById('noTemplateMessage');
  if (noTemplateMsg) {
    noTemplateMsg.classList.add('hidden');
  }
}

/**
 * Mostrar formulario dinámico
 */
function showDynamicForm() {
  const dynamicForm = document.getElementById('dynamicFormContainer');
  if (dynamicForm) {
    dynamicForm.classList.remove('hidden');
  }
}

/**
 * Renderizar formulario dinámico basado en configuración
 */
function renderDynamicForm(config) {
  const container = document.getElementById('dynamicFormFields');
  const formTitle = document.getElementById('formTitle');
  
  formTitle.textContent = `📝 ${config.name}`;
  container.innerHTML = '';

  config.fields.forEach(field => {
    const formGroup = document.createElement('div');
    formGroup.className = 'form-group';
    
    // Campos de texto largo ocupan todo el ancho
    if (field.type === 'textarea') {
      formGroup.classList.add('full-width');
    }

    // Label
    const label = document.createElement('label');
    label.setAttribute('for', field.name);
    label.innerHTML = `${field.label}${field.required ? ' <span class="required">*</span>' : ''}`;
    formGroup.appendChild(label);

    // Input
    const input = createFormInput(field);
    formGroup.appendChild(input);
    container.appendChild(formGroup);
  });
}

/**
 * Crear input según tipo de campo
 */
function createFormInput(field) {
  let input;

  switch (field.type) {
    case 'textarea':
      input = document.createElement('textarea');
      input.rows = 4;
      break;
      
    case 'select':
      input = document.createElement('select');
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.textContent = '-- Selecciona --';
      input.appendChild(defaultOption);
      
      field.options?.forEach(option => {
        const opt = document.createElement('option');
        opt.value = option;
        opt.textContent = option;
        input.appendChild(opt);
      });
      break;
      
    default:
      input = document.createElement('input');
      input.type = field.type;
  }

  input.id = field.name;
  input.name = field.name;
  input.placeholder = field.placeholder || '';
  input.required = field.required || false;

  if (field.maxLength) {
    input.maxLength = field.maxLength;
  }

  return input;
}

/**
 * ====================================
 * GENERACIÓN DE PDFs
 * ====================================
 */

/**
 * Generar PDF desde plantilla
 */
async function generatePDFFromTemplate() {
  if (!currentTemplateConfig) {
    showMessage('❌ No se ha seleccionado ninguna plantilla', 'error');
    return;
  }

  // Recopilar datos del formulario
  const formData = collectFormData();

  // Validar campos requeridos
  const validation = validateFormData(formData);
  if (!validation.valid) {
    showMessage(`⚠️ Faltan campos requeridos: ${validation.missingFields.join(', ')}`, 'error');
    return;
  }

  // Mostrar loading
  showLoading(true);

  // Enviar petición
  try {
    const response = await fetch('/generate-pdf-from-template', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        templateFileName: currentTemplateConfig.fileName,
        formData
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.details || 'Error al generar PDF');
    }

    await downloadPDF(response, `${currentTemplateConfig.id}_${Date.now()}.pdf`);
    showMessage('✅ ¡PDF generado exitosamente!', 'success');
  } catch (error) {
    console.error('❌ Error generando PDF:', error);
    showMessage(`❌ Error al generar PDF: ${error.message}`, 'error');
  } finally {
    showLoading(false);
  }
}

/**
 * ====================================
 * UTILIDADES DE FORMULARIO
 * ====================================
 */

/**
 * Recopilar datos del formulario dinámico
 */
function collectFormData() {
  const formData = {};
  
  if (!currentTemplateConfig) return formData;

  currentTemplateConfig.fields.forEach(field => {
    const input = document.getElementById(field.name);
    if (input) {
      formData[field.name] = input.value.trim();
    }
  });

  return formData;
}

/**
 * Validar datos del formulario
 */
function validateFormData(formData) {
  const missingFields = currentTemplateConfig.fields
    .filter(field => field.required && !formData[field.name])
    .map(field => field.label);

  return {
    valid: missingFields.length === 0,
    missingFields
  };
}

/**
 * Limpiar formulario
 */
function clearForm() {
  if (confirm('¿Estás seguro de que deseas limpiar todos los campos?')) {
    document.getElementById('dynamicFormFields')
      .querySelectorAll('input, textarea, select')
      .forEach(input => {
        input.value = '';
      });
    showMessage('🔄 Formulario limpiado', 'success');
  }
}

/**
 * ====================================
 * UTILIDADES
 * ====================================
 */

/**
 * Descargar PDF desde respuesta
 */
async function downloadPDF(response, filename) {
  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}

/**
 * Mostrar/ocultar loading spinner
 */
function showLoading(show) {
  const loading = document.getElementById('loading');
  if (show) {
    loading.classList.add('active');
  } else {
    loading.classList.remove('active');
  }
}

/**
 * Mostrar mensajes al usuario
 */
function showMessage(message, type) {
  const container = document.getElementById('messageContainer');
  container.textContent = message;
  container.className = `message ${type} active`;
  
  setTimeout(() => {
    container.classList.remove('active');
  }, 5000);
}

/**
 * Escapar HTML para prevenir XSS
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * ====================================
 * EXPORTS (para testing)
 * ====================================
 */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    formatTemplateName,
    getTemplateIdFromFileName,
    escapeHtml
  };
}